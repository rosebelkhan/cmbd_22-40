<!-- include header here -->
<?php include('components/header.php'); ?>


<!-- include content here -->
<?php include('components/content.php'); ?>


<!-- include footer here -->
<?php include('components/footer.php'); ?>




