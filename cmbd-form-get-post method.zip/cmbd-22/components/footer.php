
<div class="container">
    <div class="row">
    <div class="col-md-12 text-center">
        <p>&copy; <?php echo "Today is : " .date("Y-m-d / h:i:sa");?></p>
    </div>
        
    </div>
</div>



</body>
</html>