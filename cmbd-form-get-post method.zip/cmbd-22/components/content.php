
<div class="container">
    <div class="row">
        <div class="col-md-12">
        


<form action="<?php echo $_SERVER['PHP_SELF']?>" method="post">

</form>


<form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">


<table>

	<h2 style="color:red; padding:10px;"> * Fill Up The Full Form Below.</h2>
    <hr>


	<tr>
		<td>Name : </td>
		<td><input type="text" name="name" placeholder="Your name" required /> <span style="color:red"> *</span></td>
	</tr>



	<tr>
		<td>E-mail : </td>
		<td><input type="text" name="email" placeholder="Your email" required /> <span style="color:red"> *</span></td>
	</tr>



	<tr>
		<td>Website : </td>
		<td><input type="text" name="website" placeholder="Your website" required /> <span style="color:red"> *</span></td>
	</tr>


	<tr>
		<td>Comment : </td>
		<td><textarea name="comment" rows="5" cols="40" placeholder="Your comment"></textarea></td>
	</tr>


	
	<tr>
		<td>Gender : </td>
		<td><input type="radio" name="gender" value="Female"/>Female 
			<input type="radio" name="gender" value="male"/>Male 
		</td>
	</tr>
	
	
	
	<tr>
		<td></td>
		<td><input type="submit" name="submit" value="Submit"/>
		</td>
	</tr>

</table>
</form>

</div>
    </div>
</div>




<div class="container">
    <div class="row">
        <div class="col-md-12">
        <?php


$name = $email = $website = $comment = $gender = "";
$errname = $erremail = $errwebsite = $errcomment = $errgender = "";

if($_SERVER["REQUEST_METHOD"] == "POST"){
	
	$name 		= validate($_POST["name"]);
	$email	 	= validate($_POST["email"]);
	$website 	= validate($_POST["website"]);
	$comment 	= validate($_POST["comment"]);
	$gender 	= validate($_POST["gender"]);
	
	
	echo "name :".$name."<br/>";
	echo "email :".$email."<br/>";
	echo "website :".$website."<br/>";
	echo "comment :".$comment."<br/>";
	echo "gender :".$gender."<br/>";
	
}
function validate($data){
	$data = trim($data);
	$data = stripcslashes($data);
	$data = htmlspecialchars($data);
	
	return $data;
}

?>
</div>
</div>
</div>



