<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Rosebel khan new web site</title>
    <link rel="stylesheet" href="style1.css">
</head>



<body>
<div class="bodysection template clear">
	<div class="headersite template clear">
	
		<div class="header template clear">
			<h2><a href="">Rose Academy @</a></h2>
		</div>
		
	</div>


<div class="navsection template clear">
	<div class="nav clear">
		<P>
			<a href="" id="active">Home</a> -
			<a href="">Design</a> -
			<a href="">Development</a> -
			<a href="">Software</a> -
			<a href="">Optimization</a> -	
			<a href="">Contact Us</a>	
		
		</P>
	</div>
</div>
