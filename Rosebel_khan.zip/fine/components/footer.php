<div class="footersection template clear">

	<div class="footer template clear">
		<p><a href="" alt="home"><b>Rosebe khan &copy; copyright &copy; <?php echo date("Y"); ?></b></a></p>
	</div>

</div>

</div>
</body>
</html>